package com.example.foodconnect.configuration;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

}
